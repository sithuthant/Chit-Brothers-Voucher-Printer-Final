package com.chitbrothers.wifi

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import java.util.UUID

private data class CreateRequest(
    val quantity: Int,
    val profile: String = "",
    val userGroupId: String = "",
    val comment: String = ""
)

private data class VoucherItem(
    @SerializedName("codeNo") val code: String? = null,
    @SerializedName("voucherCode") val voucherCode: String? = null,
    @SerializedName("expiryTime") val expiry: String? = null,
    @SerializedName("packageName") val packageName: String? = null
) {
    fun codeText(): String = code?.takeIf { it.isNotBlank() } ?: voucherCode.orEmpty()
}

private data class CreateResponse(
    val ok: Boolean = false,
    val count: Int = 0,
    val items: List<VoucherItem> = emptyList(),
    val error: String? = null
)

private interface Api {
    @POST("api/v1/admin/voucher/create")
    suspend fun create(
        @Header("x-admin-token") token: String,
        @Body body: CreateRequest
    ): CreateResponse
}

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
                )
            )
        }
        setContent { MaterialTheme { VoucherPrinterScreen() } }
    }

    @SuppressLint("MissingPermission")
    @Composable
    private fun VoucherPrinterScreen() {
        var baseUrl by remember { mutableStateOf("http://192.168.1.100:8080/") }
        var adminToken by remember { mutableStateOf("") }
        var quantity by remember { mutableStateOf("1") }
        var profile by remember { mutableStateOf("") }
        var userGroupId by remember { mutableStateOf("") }
        var comment by remember { mutableStateOf("") }
        var status by remember { mutableStateOf("") }
        var vouchers by remember { mutableStateOf(emptyList<VoucherItem>()) }
        var selected by remember { mutableStateOf<BluetoothDevice?>(null) }
        var devices by remember { mutableStateOf(emptyList<BluetoothDevice>()) }
        val scope = rememberCoroutineScope()

        fun loadDevices() {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            devices = adapter?.bondedDevices?.toList()?.sortedBy { it.name ?: it.address } ?: emptyList()
        }

        LaunchedEffect(Unit) { loadDevices() }

        fun api(): Api {
            val url = if (baseUrl.endsWith('/')) baseUrl else "$baseUrl/"
            return Retrofit.Builder()
                .baseUrl(url)
                .client(OkHttpClient.Builder().build())
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(Api::class.java)
        }

        fun printCodes(list: List<VoucherItem>) {
            val device = selected
            if (device == null) {
                status = "Printer မရွေးရသေးပါ"
                return
            }
            Thread {
                try {
                    val socket: BluetoothSocket = device.createRfcommSocketToServiceRecord(
                        UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
                    )
                    socket.connect()
                    socket.outputStream.use { out ->
                        out.write(byteArrayOf(0x1B, 0x40))
                        out.write("CHIT BROTHERS WIFI\n".toByteArray())
                        out.write("VOUCHER CODES\n------------------------------\n".toByteArray())
                        list.forEach { voucher ->
                            out.write((voucher.codeText() + "\n").toByteArray())
                            voucher.packageName?.takeIf { it.isNotBlank() }?.let {
                                out.write((it + "\n").toByteArray())
                            }
                            voucher.expiry?.takeIf { it.isNotBlank() }?.let {
                                out.write(("Exp: $it\n").toByteArray())
                            }
                            out.write("------------------------------\n".toByteArray())
                        }
                        out.write("Thank you\n\n\n".toByteArray())
                        out.flush()
                    }
                    socket.close()
                    runOnUiThread { status = "${list.size} ခု Printer ထုတ်ပြီးပါပြီ" }
                } catch (e: Exception) {
                    runOnUiThread { status = "Printer Error: ${e.message ?: "Unknown error"}" }
                }
            }.start()
        }

        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp)
        ) {
            Text("Chit Brothers Voucher Printer", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = baseUrl,
                onValueChange = { baseUrl = it },
                label = { Text("Backend URL") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = adminToken,
                onValueChange = { adminToken = it },
                label = { Text("Admin Token") },
                modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = quantity,
                    onValueChange = { quantity = it.filter(Char::isDigit) },
                    label = { Text("အရေအတွက်") },
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text("မှတ်ချက်") },
                    modifier = Modifier.weight(2f)
                )
            }
            OutlinedTextField(
                value = profile,
                onValueChange = { profile = it },
                label = { Text("Ruijie Profile ID") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = userGroupId,
                onValueChange = { userGroupId = it },
                label = { Text("User Group ID") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(8.dp))
            Text("Bluetooth Printer", style = MaterialTheme.typography.titleMedium)
            Button(onClick = { loadDevices() }) { Text("Paired Printer ပြန်ရှာ") }

            devices.forEach { device ->
                Row(Modifier.fillMaxWidth()) {
                    Text(
                        (device.name ?: "Unknown") + " (${device.address})",
                        Modifier.weight(1f)
                    )
                    Button(onClick = { selected = device }) {
                        Text(if (selected?.address == device.address) "ရွေးထား" else "ရွေး")
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Row {
                Button(onClick = {
                    status = "Voucher ထုတ်နေပါတယ်..."
                    scope.launch {
                        try {
                            val count = quantity.toIntOrNull()?.coerceIn(1, 500) ?: 1
                            val response = api().create(
                                adminToken,
                                CreateRequest(count, profile, userGroupId, comment)
                            )
                            vouchers = response.items
                            status = if (response.ok) {
                                "${response.count} ခု ထုတ်ပြီးပါပြီ"
                            } else {
                                response.error ?: "Failed"
                            }
                        } catch (e: Exception) {
                            status = "API Error: ${e.message ?: "Unknown error"}"
                        }
                    }
                }) { Text("Voucher ထုတ်") }

                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = { printCodes(vouchers) },
                    enabled = vouchers.isNotEmpty()
                ) { Text("Print") }
            }

            Spacer(Modifier.height(8.dp))
            Text(status)
            LazyColumn {
                items(vouchers) { voucher ->
                    Text(voucher.codeText(), Modifier.padding(vertical = 4.dp))
                }
            }
        }
    }
}
