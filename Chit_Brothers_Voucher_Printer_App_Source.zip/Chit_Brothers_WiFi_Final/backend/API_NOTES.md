# Ruijie integration notes

The implementation follows the commonly documented Ruijie Cloud flow:

1. POST AppID + Secret to the access-token endpoint.
2. Use `access_token` on subsequent calls.
3. Read voucher list for the configured group.
4. Cache vouchers locally.
5. Customer lookup reads local cache and forces a sync when the code is missing.

Common voucher fields documented by Ruijie API materials include:

- voucherCode / codeNo
- status: 1 unused, 2 in-use, 3 expired
- quota (MB)
- usedQuota (MB)
- timePeriod (minutes)
- usedTime (minutes)
- expiryTime

If the V2.0.3 manual supplied by Ruijie uses a different exact endpoint/parameter shape for your account/region, update only `backend/src/ruijie.js`; the Android app and customer API do not need to change.

Do not put AppID/Secret in Android.


Auto group detection: set RUIJIE_GROUP_NAME=CB. RUIJIE_GROUP_ID is optional and overrides auto-detection.
