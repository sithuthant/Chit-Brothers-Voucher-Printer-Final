import Database from "better-sqlite3";
import path from "node:path";
import fs from "node:fs";

const dataDir = path.resolve("data");
fs.mkdirSync(dataDir, { recursive: true });

export const db = new Database(path.join(dataDir, "chit-brothers.sqlite"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS vouchers (
  code TEXT PRIMARY KEY,
  status TEXT,
  quota_mb REAL DEFAULT 0,
  used_quota_mb REAL DEFAULT 0,
  time_period_min REAL DEFAULT 0,
  used_time_min REAL DEFAULT 0,
  expiry_time TEXT,
  package_name TEXT,
  price REAL,
  max_clients INTEGER,
  current_clients INTEGER,
  raw_json TEXT,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS promotions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  image_url TEXT DEFAULT '',
  published INTEGER NOT NULL DEFAULT 1,
  starts_at TEXT,
  ends_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS announcements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  published INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
`);

export function upsertVoucher(v) {
  db.prepare(`
    INSERT INTO vouchers
      (code,status,quota_mb,used_quota_mb,time_period_min,used_time_min,
       expiry_time,package_name,price,max_clients,current_clients,raw_json,updated_at)
    VALUES
      (@code,@status,@quota_mb,@used_quota_mb,@time_period_min,@used_time_min,
       @expiry_time,@package_name,@price,@max_clients,@current_clients,@raw_json,@updated_at)
    ON CONFLICT(code) DO UPDATE SET
      status=excluded.status,
      quota_mb=excluded.quota_mb,
      used_quota_mb=excluded.used_quota_mb,
      time_period_min=excluded.time_period_min,
      used_time_min=excluded.used_time_min,
      expiry_time=excluded.expiry_time,
      package_name=excluded.package_name,
      price=excluded.price,
      max_clients=excluded.max_clients,
      current_clients=excluded.current_clients,
      raw_json=excluded.raw_json,
      updated_at=excluded.updated_at
  `).run(v);
}

export function findVoucher(code) {
  return db.prepare("SELECT * FROM vouchers WHERE code = ?").get(code);
}

export function listPublishedPromotions() {
  return db.prepare(`
    SELECT * FROM promotions
    WHERE published = 1
      AND (starts_at IS NULL OR starts_at = '' OR starts_at <= datetime('now'))
      AND (ends_at IS NULL OR ends_at = '' OR ends_at >= datetime('now'))
    ORDER BY id DESC
  `).all();
}

export function listPublishedAnnouncements() {
  return db.prepare(`
    SELECT * FROM announcements
    WHERE published = 1
    ORDER BY id DESC
  `).all();
}
