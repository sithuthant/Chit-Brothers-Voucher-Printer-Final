import "dotenv/config";

const BASE = process.env.RUIJIE_BASE_URL || "https://cloud-as.ruijienetworks.com";
let cachedToken = null;
let tokenExpiresAt = 0;

function mode() {
  return (process.env.RUIJIE_MODE || "demo").toLowerCase();
}

function apiError(message, status = 502) {
  const e = new Error(message);
  e.status = status;
  return e;
}

async function jsonFetch(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: {
      "Accept": "application/json",
      ...(options.body ? {"Content-Type": "application/json"} : {}),
      ...(options.headers || {})
    }
  });
  const text = await res.text();
  let body;
  try { body = JSON.parse(text); } catch { body = { raw: text }; }
  if (!res.ok) throw apiError(`Ruijie HTTP ${res.status}: ${JSON.stringify(body)}`, 502);
  return body;
}

async function getAccessToken() {
  if (cachedToken && Date.now() < tokenExpiresAt - 60_000) return cachedToken;

  const path = process.env.RUIJIE_TOKEN_PATH || "/service/api/oauth20/client/access_token";
  const url = new URL(path, BASE);
  // Some versions document a token query parameter; the body remains the
  // primary AppID/secret input used by current integrations.
  const body = {
    appid: process.env.RUIJIE_APP_ID,
    secret: process.env.RUIJIE_SECRET_KEY
  };

  const data = await jsonFetch(url, { method: "POST", body: JSON.stringify(body) });
  const token = data?.accessToken || data?.data?.accessToken || data?.token;
  if (!token) throw apiError(`Ruijie token response did not contain accessToken: ${JSON.stringify(data)}`);

  cachedToken = token;
  const expiresIn = Number(data?.expiresIn || data?.data?.expiresIn || 3600);
  tokenExpiresAt = Date.now() + expiresIn * 1000;
  return cachedToken;
}

function normalizeVoucher(x) {
  const code = String(x?.voucherCode ?? x?.codeNo ?? x?.code ?? "").trim();
  if (!code) return null;

  const quota = Number(x?.quota ?? 0);
  const usedQuota = Number(x?.usedQuota ?? x?.usedQuotaMb ?? 0);

  return {
    code,
    status: String(x?.status ?? ""),
    quota_mb: quota,
    used_quota_mb: usedQuota,
    time_period_min: Number(x?.timePeriod ?? 0),
    used_time_min: Number(x?.usedTime ?? 0),
    expiry_time: x?.expiryTime ?? "",
    package_name: x?.packageName ?? x?.name ?? "",
    price: Number(x?.packagePrice ?? x?.price ?? 0),
    max_clients: Number(x?.maxClients ?? x?.limitClients ?? 0),
    current_clients: Number(x?.currentClients ?? 0),
    raw_json: JSON.stringify(x),
    updated_at: new Date().toISOString()
  };
}

function extractList(data) {
  return (
    data?.list ||
    data?.data?.list ||
    data?.voucherData?.list ||
    data?.voucherData?.data?.list ||
    data?.data ||
    []
  );
}

async function resolveGroupId(token) {
  if (process.env.RUIJIE_GROUP_ID) return process.env.RUIJIE_GROUP_ID;

  const path = process.env.RUIJIE_GROUP_TREE_PATH || "/service/api/group/single/tree";
  const url = new URL(path, BASE);
  url.searchParams.set("access_token", token);
  url.searchParams.set("depth", "BUILDING");
  const data = await jsonFetch(url);

  const roots = Array.isArray(data?.groups) ? data.groups :
    (Array.isArray(data?.data?.groups) ? data.data.groups : []);
  const groups = [];
  const walk = (items) => {
    for (const g of items || []) {
      if (g && g.groupId != null) groups.push(g);
      if (Array.isArray(g?.subGroups)) walk(g.subGroups);
      if (Array.isArray(g?.children)) walk(g.children);
    }
  };
  walk(roots);

  const wanted = String(process.env.RUIJIE_GROUP_NAME || "CB").trim().toLowerCase();
  const exact = groups.find(g => String(g.name || "").trim().toLowerCase() === wanted);
  const match = exact || groups.find(g => String(g.name || "").toLowerCase().includes(wanted));
  if (!match) {
    const names = groups.map(g => `${g.name || "(unnamed)"}:${g.groupId}`).join(", ");
    throw apiError(`Could not auto-detect Ruijie group. Set RUIJIE_GROUP_NAME or RUIJIE_GROUP_ID. Available: ${names}`, 500);
  }
  return String(match.groupId);
}

export async function createVouchers({ quantity = 1, profile = "", userGroupId = "", comment = "" } = {}) {
  if (mode() === "demo") {
    return Array.from({ length: Math.max(1, Math.min(500, Number(quantity) || 1)) }, (_, i) => ({
      codeNo: `DEMO-${String(Date.now()).slice(-6)}-${String(i + 1).padStart(2, "0")}`,
      expiryTime: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
      packageName: "Demo Voucher"
    }));
  }
  const token = await getAccessToken();
  const groupId = await resolveGroupId(token);
  const finalProfile = profile || process.env.RUIJIE_VOUCHER_PROFILE || "";
  const finalUserGroupId = userGroupId || process.env.RUIJIE_USER_GROUP_ID || "";
  if (!finalProfile || !finalUserGroupId) {
    throw apiError("Voucher package is not configured. Set RUIJIE_VOUCHER_PROFILE and RUIJIE_USER_GROUP_ID.", 500);
  }
  const qty = Math.max(1, Math.min(500, Number(quantity) || 1));
  const path = (process.env.RUIJIE_VOUCHER_CREATE_PATH || "/service/api/open/auth/voucher/create/{groupId}")
    .replace("{groupId}", encodeURIComponent(groupId));
  const url = new URL(path, BASE);
  url.searchParams.set("access_token", token);
  const data = await jsonFetch(url, {
    method: "POST",
    body: JSON.stringify({ quantity: qty, profile: finalProfile, userGroupId: Number(finalUserGroupId), comment })
  });
  return data?.data?.list || data?.data || data?.list || [];
}

export async function fetchAllVouchers() {
  if (mode() === "demo") {
    return [{
      code: "DEMO1234",
      status: "2",
      quota_mb: 5120,
      used_quota_mb: 2150,
      time_period_min: 240,
      used_time_min: 80,
      expiry_time: new Date(Date.now() + 4 * 3600 * 1000).toISOString(),
      package_name: "4H / 5GB",
      price: 0,
      max_clients: 1,
      current_clients: 1,
      raw_json: "{}",
      updated_at: new Date().toISOString()
    }];
  }

  if (!process.env.RUIJIE_APP_ID || !process.env.RUIJIE_SECRET_KEY) {
    throw apiError("Live mode requires RUIJIE_APP_ID and RUIJIE_SECRET_KEY.", 500);
  }

  const token = await getAccessToken();
  const groupId = await resolveGroupId(token);
  const template = process.env.RUIJIE_VOUCHER_LIST_PATH ||
    "/service/api/open/auth/voucher/getList/{groupId}";

  const all = [];
  const pageSize = 500;
  for (let page = 0; page < 100; page++) {
    const start = page * pageSize;
    const path = template.replace("{groupId}", encodeURIComponent(groupId));
    const url = new URL(path, BASE);
    url.searchParams.set("access_token", token);
    // Support both modern pageIndex/pageSize and older start/pageSize APIs.
    url.searchParams.set("pageIndex", String(page + 1));
    url.searchParams.set("pageSize", String(pageSize));
    url.searchParams.set("start", String(start));
    if (process.env.RUIJIE_TENANT_ID) url.searchParams.set("tenantId", process.env.RUIJIE_TENANT_ID);

    const data = await jsonFetch(url);
    const list = extractList(data).map(normalizeVoucher).filter(Boolean);
    all.push(...list);

    const count = Number(data?.count ?? data?.data?.count ?? data?.voucherData?.count ?? 0);
    if (list.length < pageSize || (count && all.length >= count)) break;
  }
  return all;
}

export function demoMode() {
  return mode() === "demo";
}
