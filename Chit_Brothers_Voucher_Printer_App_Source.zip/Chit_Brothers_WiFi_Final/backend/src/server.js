import "dotenv/config";
import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { db, upsertVoucher, findVoucher, listPublishedPromotions, listPublishedAnnouncements } from "./db.js";
import { fetchAllVouchers, createVouchers, demoMode } from "./ruijie.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 8080);

app.use(cors({ origin: process.env.CORS_ORIGIN || "*" }));
app.use(express.json({ limit: "1mb" }));

const customerLimiter = rateLimit({
  windowMs: 60_000,
  limit: 60,
  standardHeaders: true,
  legacyHeaders: false
});
app.use("/api/v1/voucher", customerLimiter);

function admin(req, res, next) {
  const token = req.get("x-admin-token");
  if (!token || token !== process.env.ADMIN_TOKEN) return res.status(401).json({ error: "Unauthorized" });
  next();
}

function toClientVoucher(v) {
  if (!v) return null;
  const remainingMb = Math.max(0, Number(v.quota_mb || 0) - Number(v.used_quota_mb || 0));
  const remainingMin = Math.max(0, Number(v.time_period_min || 0) - Number(v.used_time_min || 0));
  return {
    code: v.code,
    status: v.status,
    quotaMb: Number(v.quota_mb || 0),
    usedQuotaMb: Number(v.used_quota_mb || 0),
    remainingQuotaMb: remainingMb,
    timePeriodMin: Number(v.time_period_min || 0),
    usedTimeMin: Number(v.used_time_min || 0),
    remainingTimeMin: remainingMin,
    expiryTime: v.expiry_time || null,
    packageName: v.package_name || "",
    price: Number(v.price || 0),
    maxClients: Number(v.max_clients || 0),
    currentClients: Number(v.current_clients || 0),
    updatedAt: v.updated_at
  };
}

let lastSyncAt = 0;
let syncPromise = null;

async function syncVouchers(force = false) {
  const interval = Number(process.env.VOUCHER_SYNC_MINUTES || 5) * 60_000;
  if (!force && Date.now() - lastSyncAt < interval) return;
  if (syncPromise) return syncPromise;

  syncPromise = (async () => {
    const list = await fetchAllVouchers();
    const tx = db.transaction((rows) => rows.forEach(upsertVoucher));
    tx(list);
    lastSyncAt = Date.now();
    return list.length;
  })();

  try { return await syncPromise; }
  finally { syncPromise = null; }
}

app.get("/api/v1/health", async (_req, res) => {
  res.json({
    ok: true,
    mode: demoMode() ? "demo" : "live",
    lastSyncAt: lastSyncAt ? new Date(lastSyncAt).toISOString() : null
  });
});

app.get("/api/v1/promotions", (_req, res) => res.json({ items: listPublishedPromotions() }));
app.get("/api/v1/announcements", (_req, res) => res.json({ items: listPublishedAnnouncements() }));

app.post("/api/v1/voucher/check", async (req, res) => {
  const code = String(req.body?.code || "").trim();
  if (!code || code.length > 64) return res.status(400).json({ error: "Voucher code is required." });

  try {
    await syncVouchers(false);
    let v = findVoucher(code);

    // If it is not in cache, force one sync. This keeps new/just-created
    // vouchers discoverable without making every request expensive.
    if (!v) {
      await syncVouchers(true);
      v = findVoucher(code);
    }

    if (!v) return res.status(404).json({ error: "Voucher not found." });
    res.json({ voucher: toClientVoucher(v) });
  } catch (e) {
    res.status(e.status || 502).json({ error: e.message || "Ruijie API error." });
  }
});

app.post("/api/v1/admin/voucher/create", admin, async (req, res) => {
  try {
    const quantity = Math.max(1, Math.min(500, Number(req.body?.quantity || 1)));
    const profile = String(req.body?.profile || "").trim();
    const userGroupId = String(req.body?.userGroupId || "").trim();
    const comment = String(req.body?.comment || "").trim();
    const items = await createVouchers({ quantity, profile, userGroupId, comment });
    res.json({ ok: true, count: items.length, items });
  } catch (e) {
    res.status(e.status || 502).json({ error: e.message || "Voucher creation failed." });
  }
});

app.post("/api/v1/admin/sync", admin, async (_req, res) => {
  try {
    const count = await syncVouchers(true);
    res.json({ ok: true, count, syncedAt: new Date().toISOString() });
  } catch (e) {
    res.status(e.status || 502).json({ error: e.message });
  }
});

app.get("/api/v1/admin/promotions", admin, (_req, res) => {
  res.json({ items: db.prepare("SELECT * FROM promotions ORDER BY id DESC").all() });
});

app.post("/api/v1/admin/promotions", admin, (req, res) => {
  const now = new Date().toISOString();
  const { title, body, image_url = "", published = 1, starts_at = "", ends_at = "" } = req.body || {};
  if (!title || !body) return res.status(400).json({ error: "title and body are required" });
  const info = db.prepare(`
    INSERT INTO promotions(title,body,image_url,published,starts_at,ends_at,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,?)
  `).run(title, body, image_url, published ? 1 : 0, starts_at, ends_at, now, now);
  res.json({ id: info.lastInsertRowid });
});

app.put("/api/v1/admin/promotions/:id", admin, (req, res) => {
  const now = new Date().toISOString();
  const { title, body, image_url = "", published = 1, starts_at = "", ends_at = "" } = req.body || {};
  db.prepare(`
    UPDATE promotions SET title=?, body=?, image_url=?, published=?, starts_at=?, ends_at=?, updated_at=?
    WHERE id=?
  `).run(title, body, image_url, published ? 1 : 0, starts_at, ends_at, now, req.params.id);
  res.json({ ok: true });
});

app.delete("/api/v1/admin/promotions/:id", admin, (req, res) => {
  db.prepare("DELETE FROM promotions WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

app.get("/api/v1/admin/announcements", admin, (_req, res) => {
  res.json({ items: db.prepare("SELECT * FROM announcements ORDER BY id DESC").all() });
});

app.post("/api/v1/admin/announcements", admin, (req, res) => {
  const now = new Date().toISOString();
  const { title, body, published = 1 } = req.body || {};
  if (!title || !body) return res.status(400).json({ error: "title and body are required" });
  const info = db.prepare(`
    INSERT INTO announcements(title,body,published,created_at,updated_at)
    VALUES(?,?,?,?,?)
  `).run(title, body, published ? 1 : 0, now, now);
  res.json({ id: info.lastInsertRowid });
});

app.put("/api/v1/admin/announcements/:id", admin, (req, res) => {
  const now = new Date().toISOString();
  const { title, body, published = 1 } = req.body || {};
  db.prepare(`
    UPDATE announcements SET title=?, body=?, published=?, updated_at=? WHERE id=?
  `).run(title, body, published ? 1 : 0, now, req.params.id);
  res.json({ ok: true });
});

app.delete("/api/v1/admin/announcements/:id", admin, (req, res) => {
  db.prepare("DELETE FROM announcements WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

app.use("/admin", express.static(path.resolve(__dirname, "../public")));

app.listen(PORT, () => {
  console.log(`Chit Brothers backend running on http://localhost:${PORT}`);
});
