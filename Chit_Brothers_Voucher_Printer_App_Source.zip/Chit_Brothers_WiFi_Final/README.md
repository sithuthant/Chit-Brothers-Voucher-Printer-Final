# Chit Brothers WiFi — Voucher App Final Source

Production-oriented starter for a customer Android app + Node.js backend + admin panel.

## What is included

- Android app (Kotlin + Jetpack Compose)
  - Voucher code lookup
  - Remaining / used data
  - Time remaining / expiry
  - Voucher status
  - Promotions
  - Announcements
  - Pull-to-refresh style refresh button
- Backend (Node.js + Express)
  - Ruijie Cloud API adapter
  - Access-token caching
  - Voucher sync + local SQLite cache
  - Customer API
  - Admin API
  - Rate limiting
  - Promotion/announcement CRUD
- Admin web panel
  - Create, edit, delete promotions
  - Create, edit, delete announcements
  - Publish/unpublish
- Demo mode so the project can be tested before the Ruijie connection is configured.

## Important security rule

Do NOT put Ruijie APPID or SECRET KEY inside the Android APK.

Put them only in backend `.env`.

The secret shown in the support email screenshot should be rotated/reissued before production use because it has been exposed in a screenshot/chat.

## Ruijie configuration

Copy:

    backend/.env.example

to:

    backend/.env

Then fill:

    RUIJIE_APP_ID=...
    RUIJIE_SECRET_KEY=...
    RUIJIE_GROUP_ID=...

The group ID is the numeric Network Group/Project ID used by the voucher APIs.

The adapter uses the Ruijie Cloud access-token flow and voucher list fields such as:
`voucherCode/codeNo`, `quota`, `usedQuota`, `timePeriod`, `usedTime`, `expiryTime`, `status`.

The exact endpoint paths are kept configurable because Ruijie Cloud API versions/regions can differ.

## Backend run

    cd backend
    npm install
    npm run dev

Production:

    npm start

Default API:

    http://localhost:8080

Admin panel:

    http://localhost:8080/admin/

## Android

Open `android-app` in Android Studio.

Change `API_BASE_URL` in:

    android-app/app/build.gradle.kts

to your HTTPS backend URL before installing on a phone.

## Demo

If `RUIJIE_MODE=demo`, entering any non-empty voucher code returns a sample balance.

## Production checklist

1. Rotate the exposed Ruijie secret.
2. Set `RUIJIE_MODE=live`.
3. Set `RUIJIE_GROUP_ID`.
4. Set a strong `ADMIN_TOKEN`.
5. Put backend behind HTTPS.
6. Set Android `API_BASE_URL` to HTTPS.
7. Test one real voucher and compare the numbers with Ruijie Cloud.
8. Do not expose `/admin` publicly without authentication.


Auto group detection: set RUIJIE_GROUP_NAME=CB. RUIJIE_GROUP_ID is optional and overrides auto-detection.
