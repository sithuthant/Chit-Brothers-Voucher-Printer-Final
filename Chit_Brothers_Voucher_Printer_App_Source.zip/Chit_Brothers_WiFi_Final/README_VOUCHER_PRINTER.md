# Chit Brothers Voucher Printer

ဒီ version က Android ဖုန်း + Bluetooth thermal printer ကနေ Ruijie Cloud voucher အသစ်ထုတ်ပြီး print လုပ်ရန်ဖြစ်သည်။

## App flow
1. Backend URL ထည့်ပါ။
2. Admin Token ထည့်ပါ။
3. Ruijie Profile ID / User Group ID ထည့်ပါ (backend `.env` ထဲမှာ သတ်မှတ်ထားရင် app မှာ blank ထားလို့ရသည်)။
4. Bluetooth printer ကို Android Settings မှာ Pair လုပ်ပါ။
5. App ထဲမှာ Paired Printer ကိုရွေးပါ။
6. Voucher အရေအတွက်ရွေး → `Voucher ထုတ်` → `Print`။

## Backend config
`backend/.env` မှာ `RUIJIE_VOUCHER_PROFILE` နှင့် `RUIJIE_USER_GROUP_ID` ကို သင့် Ruijie package အလိုက် ဖြည့်နိုင်သည်။

API credential တွေကို APK ထဲမထည့်ထားဘဲ backend မှာပဲထားပါ။

## API
`POST /api/v1/admin/voucher/create`
Header: `x-admin-token`
Body: `{ quantity, profile, userGroupId, comment }`

Ruijie Cloud ရဲ့ modern voucher create endpoint ကို backend ကသုံးထားသည်။ Endpoint က `POST /service/api/open/auth/voucher/create/{groupId}` ဖြစ်ပြီး call တစ်ကြိမ်လျှင် voucher 500 ခုအထိ generate လုပ်နိုင်သည်။
